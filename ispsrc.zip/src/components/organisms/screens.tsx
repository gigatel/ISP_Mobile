import {Loader} from '@molecules';
import {StatusBar} from 'expo-status-bar';
import React, {useRef} from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  View,
  ViewStyle,
} from 'react-native';

interface ScreenProps {
  isSafeArea?: boolean;
  isNavSafeArea?: boolean;
  children: React.ReactNode;
  fixedComponent?: React.ReactNode;
  fixedBottomComponent?: React.ReactNode;
  statusBarStyle?: 'light' | 'dark';
  translucent?: boolean;
  statusBgColor?: string;
  navBarColor?: string;
  loading?: boolean;
  bounces?: boolean;
  preset: 'scroll' | 'fixed';
  loaderMessage?: string;
}

const isIos = Platform.OS === 'ios';

export function Screen(props: ScreenProps) {
  const {
    isSafeArea = true,
    isNavSafeArea = true,
    loading,
    bounces,
    children,
    statusBarStyle,
    translucent = true,
    statusBgColor = 'transparent',
    navBarColor,
    preset = 'fixed',
    fixedComponent,
    fixedBottomComponent,
    loaderMessage = 'Loading',
  } = props;

  const scrollViewRef = useRef<ScrollView>(null);

  return (
    <View style={$root}>
      {/* 🔹 TOP SAFE AREA */}
      {isSafeArea && isIos && (
        <SafeAreaView
          style={[$safeareaTop, {backgroundColor: statusBgColor}]}
        />
      )}

      {/* 🔹 STATUS BAR */}
      <StatusBar
        style={statusBarStyle ?? 'light'}
        translucent={translucent}
        backgroundColor={statusBgColor}
      />

      {/* 🔹 CONTENT LAYER */}
      <View style={$contentLayer}>
        <KeyboardAvoidingView
          behavior={isIos ? 'padding' : undefined} // ❌ height removed (main fix)
          keyboardVerticalOffset={0}
          style={$keyboardAvoidingView}>
          {preset === 'fixed' ? (
            <>
              {children}
              {loading && <Loader message={loaderMessage} />}
            </>
          ) : (
            <>
              {fixedComponent}

              <ScrollView
                ref={scrollViewRef}
                bounces={bounces}
                style={$scrollView}
                contentContainerStyle={$scrollContent}
                keyboardShouldPersistTaps="handled"
                showsVerticalScrollIndicator={false}>
                {children}
              </ScrollView>

              {loading && <Loader message={loaderMessage} />}
            </>
          )}
        </KeyboardAvoidingView>
      </View>

      {/* 🔥 FIXED BOTTOM (OUTSIDE KEYBOARD + SCROLL) */}
      {preset === 'scroll' && fixedBottomComponent}

      {/* 🔹 BOTTOM SAFE AREA */}
      {isNavSafeArea && isIos && (
        <SafeAreaView
          style={[
            $safeareaBottom,
            {backgroundColor: navBarColor ?? 'transparent'},
          ]}
        />
      )}
    </View>
  );
}

/* ===================== STYLES ===================== */

const $root: ViewStyle = {
  flex: 1,
};

const $contentLayer: ViewStyle = {
  flex: 1,
};

const $keyboardAvoidingView: ViewStyle = {
  flex: 1,
};

const $scrollView: ViewStyle = {
  flex: 1,
};

const $scrollContent: ViewStyle = {
  flexGrow: 1,
};

const $safeareaTop: ViewStyle = {
  backgroundColor: 'transparent',
};

const $safeareaBottom: ViewStyle = {
  backgroundColor: 'transparent',
};
