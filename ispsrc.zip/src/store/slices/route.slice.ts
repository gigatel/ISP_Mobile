import { APIs, URLs } from '@apis';
import { Platform } from 'react-native';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { MMKV } from 'react-native-mmkv';
import { BASE_URL } from 'src/apis/urls';
const ROUTE = 'route';
const storage = new MMKV();
// ✅ Reads ALL possible token keys — logs what it finds
const getToken = (): string => {
  const keys = ['token', 'userToken', 'accessToken', 'authToken', 'Bearer', 'jwt', 'jwtToken'];
  for (const key of keys) {
    const val = storage.getString(key);
    if (val) {
      console.log(`🔑 Token found under MMKV key: "${key}"`);
      return val;
    }
  }
  // ✅ Also try getAllKeys to find the right one
  try {
    const allKeys = storage.getAllKeys();
    console.log('🗝️ All MMKV keys available:', JSON.stringify(allKeys));
  } catch (e) {
    console.log('⚠️ Could not list MMKV keys');
  }
  console.log('❌ No token found in MMKV!');
  return '';
};
/* =========================
   Types
========================= */
export interface ApiError {
  status?: number;
  success?: false;
  message?: string;
  data?: any;
}
export interface GetMasterByNameArgs {
  name?: string;
}
export interface UpdateMasterArgs {
  Id?: number;
  Name: string;
  MasterType: string;
  Address: string;
  SelectedAddress: string;
  City: string;
  State: string;
  Country: string;
  Area: string;
  PinCode: string;
  Landmark: string;
  LatLng: string;
  Image1?: string;
  Image2?: string;
  ImageFile1?: any;
  ImageFile2?: any;
  Extra1?: string;
  Extra2?: string;
}
export interface AddRouteArgs {
  Id?: number;
  RouteName: string;
  RouteLength: number;
  StartAddress: string;
  StartCity: string;
  StartState: string;
  StartCountry: string;
  StartArea: string;
  StartPincode: number;
  StartLandmark: string;
  StartLatLng: string;
  EndAddress: string;
  EndCity: string;
  EndState: string;
  EndCountry: string;
  EndArea: string;
  EndPincode: number;
  EndLandmark: string;
  EndLatLng: string;
  // RouteId?: string;
  RoutePath: any;
  RouteChamberMappingVM: any;
}
type LoadingState = 'idle' | 'pending' | 'fulfilled' | 'rejected';
interface RouteState {
  masterListLoading: LoadingState;
  masterList: any[] | null;
  error: string | null;
  routeLoading: LoadingState;
  routeResponse: any | null;
}
const initialState: RouteState = {
  masterListLoading: 'idle',
  masterList: null,
  error: null,
  routeLoading: 'idle',
  routeResponse: null,
};
/* =========================
   Get Master By Name
========================= */
export const GetMasterByNameAPI = createAsyncThunk<
  any,
  GetMasterByNameArgs | undefined,
  { rejectValue: ApiError }
>(
  `${ROUTE}/GetMasterByName`,
  async (args, thunkApi) => {
    try {
      const { name = '' } = args ?? {};
      const queryParams = name ? `?name=${encodeURIComponent(name)}` : '';
      const res = await APIs.getRequestWithQuery({
        path: URLs.getISPMasterListByname,
        params: queryParams,
        isAuth: true,
      });
      if (res?.status === 200 && res?.success) return res?.data;
      return thunkApi.rejectWithValue(res);
    } catch (error: any) {
      return thunkApi.rejectWithValue(error);
    }
  }
);
export const GetDataCenterListAPI = createAsyncThunk<any, void, { rejectValue: ApiError }>(
  `${ROUTE}/GetDataCenterList`,
  async (_, thunkApi) => {
    try {
      const res = await APIs.getRequestWithQuery({ path: URLs.getDataCenterList, isAuth: true });
      if (res?.status === 200 && res?.success) return res?.data;
      return thunkApi.rejectWithValue(res);
    } catch (error: any) {
      return thunkApi.rejectWithValue(error);
    }
  }
);
export const UpdateMasterAPI = createAsyncThunk<any, UpdateMasterArgs, { rejectValue: ApiError }>(
  `${ROUTE}/UpdateMaster`,
  async (payload, thunkApi) => {
    try {
      const formData = new FormData();
      formData.append('Id', String(payload.Id ?? 0));
      formData.append('Name', payload.Name);
      formData.append('MasterType', payload.MasterType);
      formData.append('Address', payload.Address);
      formData.append('SelectedAddress', payload.SelectedAddress);
      formData.append('City', payload.City);
      formData.append('State', payload.State);
      formData.append('Country', payload.Country);
      formData.append('Area', payload.Area);
      formData.append('PinCode', payload.PinCode);
      formData.append('Landmark', payload.Landmark);
      formData.append('LatLng', payload.LatLng);
      if (payload.Extra1) formData.append('Extra1', payload.Extra1);
      if (payload.Extra2) formData.append('Extra2', payload.Extra2);
      if (payload.Image1) formData.append('Image1', payload.Image1);
      if (payload.Image2) formData.append('Image2', payload.Image2);
      if (payload.ImageFile1) {
        formData.append('ImageFile1', {
          uri: payload.ImageFile1.uri,
          type: payload.ImageFile1.type,
          name: payload.ImageFile1.fileName || 'image1.jpg',
        });
      }
      if (payload.ImageFile2) {
        formData.append('ImageFile2', {
          uri: payload.ImageFile2.uri,
          type: payload.ImageFile2.type,
          name: payload.ImageFile2.fileName || 'image2.jpg',
        });
      }
      const res = await APIs.postRequestWithFormData({
        path: URLs.updateMasterAPI,
        body: formData,
        isAuth: true,
        isFormData: true,
      });
      if (res?.status === 200 && res?.success) return res?.data;
      return thunkApi.rejectWithValue(res);
    } catch (error: any) {
      return thunkApi.rejectWithValue(error);
    }
  }
);
/* =================================================
   ✅ FIXED addRouteAPI
   - Static hardcoded URL
   - MMKV token with full key scan + debug
   - Direct fetch — NO Content-Type header (RN auto-adds boundary)
   - Full response logging
================================================= */
export const addRouteAPI = createAsyncThunk<
  any,
  AddRouteArgs,
  { rejectValue: ApiError }
>(
  `${ROUTE}/addRouteAPI`,
  async (payload, thunkApi) => {
    try {
      const formData = new FormData();
      formData.append('Id', String(payload.Id ?? 0));
      // formData.append('RouteId', String(payload.RouteId ?? '0'));
      formData.append('RouteName', String(payload.RouteName ?? ''));
      formData.append('RouteLength', String(payload.RouteLength ?? 0));
      formData.append('RouteCreatedFrom', Platform.OS);
      formData.append('StartLatLng', String(payload.StartLatLng ?? ''));
      formData.append('StartAddress', String(payload.StartAddress ?? ''));
      formData.append('StartLandmark', String(payload.StartLandmark ?? ''));
      formData.append('StartArea', String(payload.StartArea ?? ''));
      formData.append('StartCity', String(payload.StartCity ?? ''));
      formData.append('StartState', String(payload.StartState ?? ''));
      formData.append('StartCountry', String(payload.StartCountry ?? ''));
      formData.append('StartPincode', String(payload.StartPincode ?? 0));
      formData.append('EndLatLng', String(payload.EndLatLng ?? ''));
      formData.append('EndAddress', String(payload.EndAddress ?? ''));
      formData.append('EndCity', String(payload.EndCity ?? ''));
      formData.append('EndState', String(payload.EndState ?? ''));
      formData.append('EndCountry', String(payload.EndCountry ?? ''));
      formData.append('EndArea', String(payload.EndArea ?? ''));
      formData.append('EndPincode', String(payload.EndPincode ?? 0));
      formData.append('EndLandmark', String(payload.EndLandmark ?? ''));
      formData.append('RoutePath', String(payload.RoutePath ?? ''));
      if (Array.isArray(payload.RouteChamberMappingVM) && payload.RouteChamberMappingVM.length > 0) {
        payload.RouteChamberMappingVM.forEach((item: any, index: number) => {
          const k = `RouteChamberMappingVM[${index}]`;
          formData.append(`${k}.MasterType`, String(item.masterType ?? ''));
          formData.append(`${k}.MasterId`, String(item.masterId ?? 0));
          formData.append(`${k}.Distance`, String(item.distance ?? 0));
          formData.append(`${k}.LatLng`, String(item.latLng ?? ''));
          formData.append(`${k}.SelectedAddress`, String(item.selectedAddress ?? ''));
          formData.append(`${k}.Pincode`, String(item.pincode ?? 0));
          formData.append(`${k}.Area`, String(item.area ?? ''));
          formData.append(`${k}.City`, String(item.city ?? ''));
          formData.append(`${k}.State`, String(item.state ?? ''));
          formData.append(`${k}.Country`, String(item.country ?? ''));
          formData.append(`${k}.Extra1`, String(item.extra1 ?? ''));
          formData.append(`${k}.Extra2`, String(item.extra2 ?? ''));
          formData.append(`${k}.Address`, String(item.address ?? ''));
          formData.append(`${k}.Landmark`, String(item.landmark ?? ''));
          formData.append(`${k}.orderNo`, String(index + 1));
          // if (item.imageFile1?.uri)  mageFile1`, {
          //     uri: item.imageFile1.uri,
          //     type: item.imageFile1.type || 'image/jpeg',
          //     name: item.imageFile1.fileName || 'image1.jpg',
          //   } as any);
          // }
          // if (item.imageFile2?.uri) {
          //   formData.append(`${k}.ImageFile2`, {
          //     uri: item.imageFile2.uri,
          //     type: item.imageFile2.type || 'image/jpeg',
          //     name: item.imageFile2.fileName || 'image2.jpg',
          //   } as any);
          // }
        });
      }
      const res = await APIs.postRequestWithFormData({
        // path: 'http://mob.gigatel.me:60107/api/RouteMasterMob/InsertUpdateRouteMasterMob', 
        path: URLs.updateRouteAPI,
        body: formData,
        isAuth: true,
        isFormData: true,
      });
      if (res?.status === 200 || res?.success) {
        return res?.data ?? res;
      }
      return thunkApi.rejectWithValue({
        status: res?.status,
        message: res?.message || res?.title || JSON.stringify(res?.errors) || `Server error: ${res?.status}`,
        data: res,
      });
    } catch (error: any) {
      console.error('❌ [addRouteAPI] request threw error:', error);
      return thunkApi.rejectWithValue({
        message: error?.message || 'Network error. Is the server reachable?',
      });
    }
  }
);

export const GetRackMasterListAPI = createAsyncThunk<any, void, { rejectValue: ApiError }>(
  `${ROUTE}/GetRackMasterList`,
  async (_, thunkApi) => {
    try {
      const res = await APIs.getRequestWithQuery({ path: URLs.getRackMasterList, isAuth: true });
      if (res?.status === 200 && res?.success) return res?.data;
      return thunkApi.rejectWithValue(res);
    } catch (error: any) {
      return thunkApi.rejectWithValue(error);
    }
  }
);
export const GetFmsMasterListAPI = createAsyncThunk<any, void, { rejectValue: ApiError }>(
  `${ROUTE}/GetFmsMasterList`,
  async (_, thunkApi) => {
    try {
      const res = await APIs.getRequestWithQuery({ path: URLs.getFmsMasterList, isAuth: true });
      if (res?.status === 200 && res?.success) return res?.data;
      return thunkApi.rejectWithValue(res);
    } catch (error: any) {
      return thunkApi.rejectWithValue(error);
    }
  }
);

export const GetLcoMasterListAPI = createAsyncThunk<any, void, { rejectValue: ApiError }>(
  `${ROUTE}/GetLcoMasterList`,
  async (_, thunkApi) => {
    try {
      const res = await APIs.getRequestWithQuery({ path: URLs.getLcoMasterList, isAuth: true });
      if (res?.status === 200 && res?.success) return res?.data;
      return thunkApi.rejectWithValue(res);
    } catch (error: any) {
      return thunkApi.rejectWithValue(error);
    }
  }
);

const routeSlice = createSlice({
  name: ROUTE,
  initialState,
  reducers: {
    clearMasterList: (state) => { state.masterList = null; },
    clearRouteError: (state) => { state.error = null; },
  },
  extraReducers: (builder) => {
    const handlePending = (state: RouteState) => {
      state.masterListLoading = 'pending';
      state.error = null;
    };
    const handleFulfilled = (state: RouteState, action: any) => {
      state.masterListLoading = 'fulfilled';
      state.masterList = action.payload;
    };
    const handleRejected = (state: RouteState, action: any) => {
      state.masterListLoading = 'rejected';
      state.error = action.payload?.message || 'Something went wrong';
    };

    builder
      .addCase(GetMasterByNameAPI.pending, handlePending)
      .addCase(GetMasterByNameAPI.fulfilled, handleFulfilled)
      .addCase(GetMasterByNameAPI.rejected, handleRejected)
      .addCase(GetDataCenterListAPI.pending, handlePending)
      .addCase(GetDataCenterListAPI.fulfilled, handleFulfilled)
      .addCase(GetDataCenterListAPI.rejected, handleRejected)
      .addCase(GetRackMasterListAPI.pending, handlePending)
      .addCase(GetRackMasterListAPI.fulfilled, handleFulfilled)
      .addCase(GetRackMasterListAPI.rejected, handleRejected)
      .addCase(GetFmsMasterListAPI.pending, handlePending)
      .addCase(GetFmsMasterListAPI.fulfilled, handleFulfilled)
      .addCase(GetFmsMasterListAPI.rejected, handleRejected)
      .addCase(GetLcoMasterListAPI.pending, handlePending)
      .addCase(GetLcoMasterListAPI.fulfilled, handleFulfilled)
      .addCase(GetLcoMasterListAPI.rejected, handleRejected)
      .addCase(addRouteAPI.pending, (state) => {
        state.routeLoading = 'pending';
        state.error = null;
      })
      .addCase(addRouteAPI.fulfilled, (state, action) => {
        state.routeLoading = 'fulfilled';
        state.routeResponse = action.payload;
      })
      .addCase(addRouteAPI.rejected, (state, action: any) => {
        state.routeLoading = 'rejected';
        state.error = action.payload?.message || 'Something went wrong';
      });
  },
});

export const { clearMasterList, clearRouteError } = routeSlice.actions;
export const routeReducer = routeSlice.reducer;
