/*
 @ 𝔸𝕦𝕥𝕙𝕠𝕣: ℙ𝕒𝕟𝕜𝕒𝕛 𝕂𝕦𝕞𝕒𝕣 ℙ𝕣𝕒𝕛𝕡𝕒𝕥𝕚
 @ 𝔼𝕞𝕒𝕚𝕝: 𝕡𝕜𝕡𝕣𝕒𝕛𝕡𝕒𝕥𝕚𝟙𝟙𝟡𝟡𝟟@𝕘𝕞𝕒𝕚𝕝.𝕔𝕠𝕞
*/
import {Buttons, InputField} from '@atoms';
import {BackHeader} from '@molecules';
import {Screen, AuthScreen} from '@organisms';
import {useFocusEffect} from '@react-navigation/native';
import {RootState, StoreDispatch} from '@reducers';
import {COLORS, FONTS, IMAGES, SIZE} from '@res';
import {getOtpApi, verifyOtpApi} from '@slices/login.slice';
import {ScreenProps} from '@types';
import {Common} from '@utils';
import {BoxShadow} from '../../res/globalStyle';
import React, {FC, useCallback, useEffect, useRef, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {
  ActivityIndicator,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  ImageBackground,
  View,
  AppState,
  Keyboard,
  TextInput,
} from 'react-native';
import DeviceInfo from 'react-native-device-info';
import {OtpInput, OtpInputRef} from 'react-native-otp-entry';
import {connect, useDispatch} from 'react-redux';
import messaging from '@react-native-firebase/messaging';
import {FontFamily, Padding, Border, FontSize} from '../../res/globalStyle';
type OtpVerifyModule = {
  getHash?: () => Promise<string[]>;
  startOtpListener?: (cb: (message: string) => void) => void;
  removeListener?: () => void;
} | null;
const ENABLE_AUTO_SMS = true;
const OtpVerification: FC<ScreenProps.OtpVerification> = ({
  navigation,
  route,
  loading,
}) => {
  const {t} = useTranslation();
  const params = route?.params ?? ({} as any);
  const userId: string = params.userId ?? '';
  const password: string = params.password ?? '';
  const appType: string = params.appType ?? '';
  const organizationCode: string = params.organizationCode ?? '';

  // ============ STATE ============
  const [otpCode, setOtp] = useState('');
  const [resendDisabled, setResendDisabled] = useState(false);
  const [timerCount, setTimerCount] = useState(0);
  const [fcmToken, setFcmToken] = useState<string | null>(null);
  const [apnsToken, setApnsToken] = useState<string | null>(null);
  const [fetchingOtp, setFetchingOtp] = useState(false);

  // ============ REFS ============
  const dispatch = useDispatch<StoreDispatch>();
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const otpRef = useRef<OtpInputRef | null>(null);

  // 🔐 CRITICAL: Prevent duplicate API calls
  const isVerifyingRef = useRef(false);
  const lastVerifiedCodeRef = useRef<string>('');

  const cleanupOtpListenerRef = useRef<(() => void) | null>(null);
  const tokenRefreshUnsubRef = useRef<(() => void) | null>(null);
  const appHashRef = useRef<string>('');

  // ============ FCM TOKEN SETUP ============
  useEffect(() => {
    let mounted = true;
    const initPush = async () => {
      try {
        try {
          await messaging().registerDeviceForRemoteMessages();
        } catch {}
        try {
          await messaging().setAutoInitEnabled(true);
        } catch {}
        try {
          await messaging().requestPermission({
            provisional: true,
            alert: true,
            badge: true,
            sound: true,
          });
        } catch {}
        if (Platform.OS === 'ios' && (messaging() as any).getAPNSToken) {
          try {
            const apns = await (messaging() as any).getAPNSToken();
            if (mounted && apns) setApnsToken(apns);
          } catch {}
        }
        const t = await messaging().getToken();
        if (mounted && t) setFcmToken(t);
        tokenRefreshUnsubRef.current = messaging().onTokenRefresh(nt => {
          if (!mounted) return;
          setFcmToken(nt);
        });
      } catch {}
    };
    initPush();
    return () => {
      mounted = false;
      try {
        tokenRefreshUnsubRef.current?.();
      } catch {}
      tokenRefreshUnsubRef.current = null;
    };
  }, []);

  const ensureFcmToken = useCallback(async (): Promise<string | null> => {
    if (fcmToken) return fcmToken;
    try {
      await messaging().registerDeviceForRemoteMessages();
    } catch {}
    try {
      await messaging().setAutoInitEnabled(true);
    } catch {}
    for (let i = 0; i < 12; i++) {
      try {
        const apns =
          Platform.OS === 'ios' && (messaging() as any).getAPNSToken
            ? await (messaging() as any).getAPNSToken()
            : null;
        if (apns && !apnsToken) setApnsToken(apns);
        const t = await messaging().getToken();
        if (t) {
          setFcmToken(t);
          return t;
        }
      } catch {}
      await new Promise(r => setTimeout(r, 500));
    }
    return null;
  }, [fcmToken, apnsToken]);

  // ============ TIMER ============
  useFocusEffect(
    useCallback(() => {
      startCountdown();
      return () => {
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
          intervalRef.current = null;
        }
      };
    }, []),
  );

  const startCountdown = () => {
    setTimerCount(90);
    setResendDisabled(true);
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    intervalRef.current = setInterval(() => {
      setTimerCount(prev => {
        if (prev <= 1) {
          if (intervalRef.current) {
            clearInterval(intervalRef.current);
            intervalRef.current = null;
          }
          setResendDisabled(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  // ============ 🔥 SINGLE VERIFY FUNCTION (MAIN FIX) ============
  const verifyOtp = useCallback(
    async (code: string, source: string = 'unknown') => {
      console.log(`🔍 verifyOtp called from: ${source}, code: ${code}`);

      // ✅ Guard 1: Already verifying (most important!)
      if (isVerifyingRef.current) {
        console.log('🚫 Already verifying, blocked!');
        return;
      }

      // ✅ Guard 2: Same code already verified
      if (lastVerifiedCodeRef.current === code) {
        console.log('🚫 Same code already submitted, blocked!');
        return;
      }

      // ✅ Guard 3: Code validation
      if (!code || code.length !== 6) {
        console.log('⚠️ Invalid code length');
        Common.showToast(
          code ? t('validation.invalid_otp') : t('validation.wait_for_otp'),
        );
        return;
      }

      // ✅ Guard 4: FCM token check
      const token = await ensureFcmToken();
      if (!token) {
        console.log('⚠️ FCM token not ready');
        Common.showToast('Preparing push token… please try again');
        return;
      }

      // 🔒 LOCK - Prevent any other calls
      isVerifyingRef.current = true;
      lastVerifiedCodeRef.current = code;

      console.log(`✅ VERIFYING OTP: ${code} from ${source}`);

      const deviceType = Platform.OS + '-' + DeviceInfo.getDeviceId();

      try {
        const result: any = await dispatch(
          verifyOtpApi({
            userId,
            password,
            appType,
            otp: code,
            deviceToken: token,
            deviceType,
            organizationCode,
          }),
        );

        // Check if verification was successful
        if (result?.error) {
          console.log('❌ Verification failed, resetting lock');
          // Reset on error so user can retry
          lastVerifiedCodeRef.current = '';
        } else {
          console.log('✅ Verification successful');
        }
      } catch (error) {
        console.log('❌ Verification error:', error);
        lastVerifiedCodeRef.current = '';
      } finally {
        // 🔓 UNLOCK after completion
        isVerifyingRef.current = false;
      }
    },
    [appType, dispatch, password, t, userId, ensureFcmToken, organizationCode],
  );

  // ============ OTP EXTRACTOR ============
  const extractOTP = (message: string) => {
    const m = message.match(/(^|[^0-9])([0-9]{6})(?![0-9])/);
    return m ? m[2] : null;
  };

  // ============ ANDROID SMS AUTO-FILL ============
  const startAndroidOtpPipelines = useCallback(async () => {
    if (!ENABLE_AUTO_SMS || Platform.OS !== 'android') return;

    let OtpVerify: OtpVerifyModule = null;
    try {
      OtpVerify = require('react-native-otp-verify');
    } catch {
      console.log('⚠️ react-native-otp-verify not available');
      return;
    }
    if (!OtpVerify) return;

    try {
      const hashes = (await OtpVerify.getHash?.()) ?? [];
      if (hashes.length) {
        const originalHash = hashes[0];
        const safeHash = encodeURIComponent(originalHash);
        appHashRef.current = safeHash;
        if (__DEV__) {
          console.log('🔐 Android Hash Key:', safeHash);
        }
      }
    } catch (err) {
      if (__DEV__) console.warn('[OTP] Failed to get hash', err);
    }

    // Start SMS listener
    try {
      OtpVerify.startOtpListener?.((msg: string) => {
        console.log('📱 SMS received');
        const code = extractOTP(msg) ?? '';
        if (!code) {
          console.log('⚠️ No OTP code found in SMS');
          return;
        }

        console.log('📱 SMS OTP extracted:', code);
        setOtp(code);

        const anyRef = otpRef.current as any;
        if (anyRef?.setValue) {
          anyRef.setValue(code);
        }

        // Auto-verify from SMS
        verifyOtp(code, 'android_sms_listener');
      });

      cleanupOtpListenerRef.current = () => {
        try {
          OtpVerify?.removeListener?.();
        } catch {}
      };
    } catch (err) {
      if (__DEV__) console.warn('[OTP] startOtpListener failed', err);
    }

    // Fallback user consent
    try {
      await OtpVerify.getOtp?.();
    } catch (err) {
      if (__DEV__) console.warn('[OTP] getOtp fallback failed', err);
    }
  }, [verifyOtp]);

  // Re-arm when app returns to foreground
  useEffect(() => {
    if (Platform.OS !== 'android') return;
    const sub = AppState.addEventListener('change', s => {
      if (s === 'active') {
        console.log('📱 App resumed, restarting SMS listener');
        startAndroidOtpPipelines();
      }
    });
    return () => sub.remove();
  }, [startAndroidOtpPipelines]);

  // On mount (Android): start pipelines
  useEffect(() => {
    if (Platform.OS !== 'android') return;

    let mounted = true;
    (async () => {
      await startAndroidOtpPipelines();
    })();

    return () => {
      mounted = false;
      cleanupOtpListenerRef.current?.();
    };
  }, [startAndroidOtpPipelines]);

  // ============ RESEND OTP ============
  const resendOtp = () => {
    console.log('🔄 Resending OTP');

    // Reset verification state
    isVerifyingRef.current = false;
    lastVerifiedCodeRef.current = '';

    startCountdown();

    // ✅ Send all required params including hashKey and organizationCode
    dispatch(
      getOtpApi({
        mobileNumber: userId,
        hashKey: appHashRef.current,
        organizationCode: organizationCode,
      }),
    );

    try {
      (otpRef.current as any)?.clear?.();
    } catch {}
    setOtp('');
  };

  // ============ RENDER ============
  return (
    <AuthScreen
      preset="scroll"
      loading={loading}
      statusBgColor={COLORS.BACKGROUND_DEFAULT}
      statusBarStyle={'dark'}
      fixedBottomComponent={
        <View style={styles.footerContainer}>
          <Text style={styles.footerText}>Powered by @Gigatel</Text>
        </View>
      }>
      <ImageBackground
        source={IMAGES.bkgImage}
        resizeMode="cover"
        style={styles.background}>
        <View>
          <View style={[styles.header, styles.center]}>
            <Image source={IMAGES.appLogo} style={styles.logo} />
            <Text style={styles.title}>Login to your Account</Text>
            <Text style={styles.subtitle}>Fill the details to login</Text>
          </View>

          <View style={styles.form}>
            <TextInput
              style={styles.ispInput}
              placeholder="Enter ISP ID"
              value={organizationCode}
              editable={false}
              placeholderTextColor={'#393d45'}
            />
            <InputField
              type="loginMobile"
              value={userId}
              placeholder="Enter phone no."
              maxLength={10}
              keyboardType="number-pad"
              editable={false}
              onEndEditing={Keyboard.dismiss}
              inputStyle={{height: SIZE.MVS(45)}}
            />
          </View>

          {Platform.OS === 'ios' && (
            <Text style={styles.keyboardCode}>
              {`APNs: ${apnsToken ? 'OK' : 'pending'} · FCM: ${
                fcmToken ? 'OK' : 'pending'
              }`}
            </Text>
          )}

          <View style={styles.inputContainer}>
            <OtpInput
              ref={otpRef}
              numberOfDigits={6}
              focusColor={COLORS.PRIMARY}
              autoFocus
              hideStick
              placeholder="＊＊＊＊＊＊"
              blurOnFilled={true}
              type="numeric"
              secureTextEntry={false}
              focusStickBlinkingDuration={500}
              onTextChange={text => {
                // Just update state, don't verify here
                setOtp(text);
              }}
              onFilled={code => {
                // ✅ ONLY verify when user manually completes 6 digits
                // This won't fire for SMS auto-fill because we use setValue
                if (code && code.length === 6) {
                  console.log('📝 onFilled triggered with:', code);
                  verifyOtp(code, 'manual_onFilled');
                }
              }}
              textInputProps={{
                accessibilityLabel: 'One-Time Password',
                editable: true,
                showSoftInputOnFocus: true,
                caretHidden: false,
                keyboardType: 'number-pad',
                returnKeyType: 'done',
                blurOnSubmit: true,
                autoComplete: Platform.OS === 'ios' ? 'one-time-code' : 'off',
                textContentType: Platform.OS === 'ios' ? 'oneTimeCode' : 'none',
              }}
              theme={{
                containerStyle: styles.otpContainer,
                pinCodeContainerStyle: styles.pinBox,
                pinCodeTextStyle: styles.pinCodeText,
                placeholderTextStyle: styles.placeholderText,
                filledPinCodeContainerStyle: styles.filledPinCodeContainer,
              }}
            />
          </View>

          <View style={styles.resendContainer}>
            <Text
              style={[styles.resendText, resendDisabled && {opacity: 0.5}]}
              onPress={!resendDisabled ? resendOtp : undefined}>
              {resendDisabled ? t('resend_after') : t('resend_code')}{' '}
              {timerCount > 0 && (
                <Text style={styles.timerText}>{timerCount}</Text>
              )}
              {resendDisabled ? ' sec' : ''}
            </Text>
          </View>

          {ENABLE_AUTO_SMS && Platform.OS === 'android' && (
            <View style={styles.otpLoader}>
              <Text style={styles.waitingText}>
                {'Waiting for OTP to Auto fill'}
              </Text>
            </View>
          )}
        </View>
      </ImageBackground>
    </AuthScreen>
  );
};

const MapStateToProps = (state: RootState) => ({
  loading: state.login.loading === 'pending',
});

export default connect(MapStateToProps)(OtpVerification);

// ============ STYLES ============
const styles = StyleSheet.create({
  keyboardCode: {
    fontFamily: FONTS.REGULAR,
    fontWeight: FONTS.FONT_WEIGHT.REGULAR,
    fontSize: SIZE.MVS(12),
    color: COLORS.ERROR,
    marginHorizontal: SIZE.MS(15),
    textAlign: 'center',
    marginTop: SIZE.MS(10),
  },
  waitingText: {
    fontFamily: FONTS.MEDIUM,
    fontWeight: FONTS.FONT_WEIGHT.REGULAR,
    fontSize: SIZE.MVS(13),
    color: COLORS.PRIMARY_DARK,
    textAlign: 'center',
  },
  otpLoader: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: SIZE.MS(10),
  },
  filledPinCodeContainer: {
    borderColor: COLORS.BORDER_DEFAULT,
  },
  timerText: {
    fontFamily: FONTS.BOLD,
    fontWeight: FONTS.FONT_WEIGHT.BOLD,
    fontSize: SIZE.MVS(15),
    color: COLORS.ERROR,
  },
  pinCodeText: {
    fontFamily: FONTS.MEDIUM,
    fontWeight: FONTS.FONT_WEIGHT.MEDIUM,
    fontSize: SIZE.MS(12),
    color: COLORS.TEXT_DARK,
  },
  placeholderText: {
    fontFamily: FONTS.MEDIUM,
    fontWeight: FONTS.FONT_WEIGHT.MEDIUM,
    fontSize: SIZE.MS(14),
    color: COLORS.TEXT_PLACEHOLDER,
  },
  resendContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: SIZE.MS(10),
    gap: SIZE.MS(6),
  },
  didnotText: {
    fontFamily: FONTS.BOLD,
    fontWeight: FONTS.FONT_WEIGHT.BOLD,
    fontSize: SIZE.MVS(15),
    color: COLORS.TEXT_DARK,
  },
  resendText: {
    fontFamily: FONTS.MEDIUM,
    fontWeight: FONTS.FONT_WEIGHT.MEDIUM,
    fontSize: SIZE.MVS(15),
    color: 'purple',
  },
  inputContainer: {
    marginTop: SIZE.MS(15),
    alignItems: 'center',
  },
  spacer: {flex: 1},
  descText: {
    marginHorizontal: SIZE.MS(25),
    fontFamily: FONTS.REGULAR,
    fontWeight: FONTS.FONT_WEIGHT.REGULAR,
    fontSize: SIZE.MVS(14),
    color: COLORS.TEXT_DARK,
    alignSelf: 'center',
    marginTop: SIZE.MS(30),
    marginVertical: SIZE.MS(20),
  },
  changeText: {
    fontFamily: FONTS.MEDIUM,
    fontWeight: FONTS.FONT_WEIGHT.MEDIUM,
    fontSize: SIZE.MVS(14),
    color: COLORS.PRIMARY,
  },
  otptext: {
    fontFamily: FONTS.BOLD,
    fontWeight: FONTS.FONT_WEIGHT.BOLD,
    fontSize: SIZE.MVS(25),
    color: COLORS.PRIMARY,
    alignSelf: 'center',
    marginVertical: SIZE.MS(10),
  },
  otptextVer: {
    fontFamily: FONTS.BOLD,
    fontSize: SIZE.MVS(25),
    color: COLORS.PRIMARY_DARK,
    alignSelf: 'center',
  },
  logoImge: {
    width: SIZE.MS(120),
    height: SIZE.MS(120),
    alignSelf: 'center',
    marginVertical: SIZE.MS(25),
  },
  container: {
    width: '98%',
  },
  scroll: {flex: 1},
  viewFlexBox: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonWrapper: {},
  loginButton: {
    marginHorizontal: SIZE.MS(20),
  },
  background: {
    flex: 1,
    width: '100%',
  },
  enterYourPhone: {
    fontSize: SIZE.MS(12),
    lineHeight: 17,
    textAlign: 'left',
    letterSpacing: -0.1,
    color: COLORS.colorDarkslategray,
    fontFamily: FONTS.MEDIUM,
    fontWeight: FONTS.FONT_WEIGHT.MEDIUM,
  },
  headline: {
    gap: 24,
    justifyContent: 'center',
  },
  logoSm1Icon: {
    width: 41,
    height: 41,
  },
  text: {
    width: 341,
    gap: 12,
    justifyContent: 'center',
  },
  signInTo: {
    fontSize: SIZE.MS(30),
    letterSpacing: -0.8,
    fontFamily: FONTS.SEMI_BOLD,
    fontWeight: FONTS.FONT_WEIGHT.SEMI_BOLD,
    lineHeight: 42,
    textAlign: 'center',
    alignSelf: 'stretch',
  },
  view: {
    width: '100%',
    marginTop: SIZE.MS(85),
    gap: 30,
    justifyContent: 'center',
    overflow: 'hidden',
    flex: 1,
  },
  fieldParent: {
    marginTop: SIZE.MS(30),
    alignSelf: 'stretch',
  },
  field: {
    alignItems: 'flex-end',
    alignSelf: 'stretch',
  },
  inputField: {
    gap: 10,
    alignSelf: 'stretch',
  },
  pinBox: {
    width: SIZE.MS(45),
    height: SIZE.MS(48),
    borderRadius: 6,
    borderWidth: 1,
    borderColor: COLORS.BORDER_DEFAULT,
    backgroundColor: COLORS.WHITE,
  },
  otpContainer: {
    width: '78%',
    alignSelf: 'center',
  },
  gigatelTechnosoftPvt: {
    bottom: 10,
    alignSelf: 'center',
    position: 'absolute',
    fontSize: SIZE.MS(13),
    fontFamily: FONTS.MEDIUM,
    fontWeight: FONTS.FONT_WEIGHT.MEDIUM,
    color: COLORS.colorDarkslategray,
    textAlign: 'center',
  },
  footerContainer: {
    position: 'absolute',
    bottom: SIZE.MS(12),
    right: SIZE.MS(20),
    fontSize: SIZE.MS(16),
    fontFamily: FONTS.MEDIUM,
    fontWeight: FONTS.FONT_WEIGHT.MEDIUM,
    color: COLORS.colorDarkslategray,
  },
  footerText: {
    fontSize: SIZE.MS(13),
    fontFamily: FONTS.SEMI_BOLD,
    fontWeight: FONTS.FONT_WEIGHT.SEMI_BOLD,
    color: '#19191A',
  },
  center: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  header: {
    marginTop: Platform.OS === 'ios' ? SIZE.MVS(150) : SIZE.MS(85),
    gap: 12,
  },
  logo: {
    width: 41,
    height: 41,
    resizeMode: 'contain',
  },
  title: {
    fontSize: SIZE.MS(24),
    fontFamily: FONTS.SEMI_BOLD,
    fontWeight: FONTS.FONT_WEIGHT.SEMI_BOLD,
    lineHeight: 42,
    textAlign: 'center',
    color: '#19191a',
  },
  subtitle: {
    fontSize: SIZE.MS(14),
    fontFamily: FONTS.MEDIUM,
    fontWeight: FONTS.FONT_WEIGHT.MEDIUM,
  },
  form: {
    marginTop: SIZE.MS(50),
    gap: 15,
  },
  ispInput: {
    flexDirection: 'row',
    width: '80%',
    alignSelf: 'center',
    borderRadius: 45,
    paddingHorizontal: 19,
    elevation: 15,
    boxShadow: BoxShadow.shadow_drop,
    height: 46,
    paddingVertical: 0,
    backgroundColor: COLORS.colorWhite,
    borderColor: 'transparent',
    borderStyle: 'solid',
    justifyContent: 'center',
    overflow: 'hidden',
    borderWidth: 1,
  },
});
